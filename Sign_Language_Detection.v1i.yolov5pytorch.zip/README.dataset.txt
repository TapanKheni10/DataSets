# Sign_Language_Detection > 2024-04-09 2:21pm
https://universe.roboflow.com/mysterycv/sign_language_detection-n9uur

Provided by a Roboflow user
License: MIT

